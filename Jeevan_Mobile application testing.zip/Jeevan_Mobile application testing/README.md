# Jeevan Mobile App Testing

This project contains automated mobile login tests using Appium and Python.