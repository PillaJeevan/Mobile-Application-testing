import unittest
from appium import webdriver

class MobileLoginTest(unittest.TestCase):
    def setUp(self):
        caps = {}
        caps["platformName"] = "Android"
        caps["deviceName"] = "Android Emulator"
        caps["appPackage"] = "com.example.shoppingapp"
        caps["appActivity"] = "com.example.shoppingapp.LoginActivity"
        self.driver = webdriver.Remote("http://localhost:4723/wd/hub", caps)

    def test_login_valid_user(self):
        email = self.driver.find_element("id", "com.example.shoppingapp:id/email")
        password = self.driver.find_element("id", "com.example.shoppingapp:id/password")
        login_btn = self.driver.find_element("id", "com.example.shoppingapp:id/login")

        email.send_keys("testuser@example.com")
        password.send_keys("password123")
        login_btn.click()

        self.assertTrue(self.driver.find_element("id", "com.example.shoppingapp:id/home").is_displayed())

    def tearDown(self):
        self.driver.quit()
